**Sistem Pemantauan dan Evaluasi Manajemen Pelanggaran Mahasiswa**

Aplikasi ini dibuat untuk memenuhi tugas akhir atau skripsi pada program studi teknik informatika. Aplikasi ini dibuat dengan menggunakan:
- Framework Laravel 9
- SweetAlert
- Mazer Template 
