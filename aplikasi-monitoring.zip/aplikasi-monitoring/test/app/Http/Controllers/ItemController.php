<?php

namespace App\Http\Controllers;

use App\Models\Item;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class ItemController extends Controller
{

    public function index()
    {
        $dokumen = Item::all();
        return view('dokumen.data-dokumen', compact('dokumen'));
    }

    public function store(Request $request)
    {
        $rules = [
            'nama_item' => 'required | unique:item',
        ];

        $text = [
            'nama_item.required' => 'Nama Program Studi harus diisi.',
            'nama_item.unique' => 'Dokumen yang anda masukan sudah ada.',
        ];

        $request->validate($rules, $text);

        $dokumen = Item::create([
            'nama_item' => $request->nama_item,

        ]);

        if ($dokumen) {
            Alert::toast('Berhasil menambah data Dokumen Sitaan.', 'success');
            return redirect()->route('dokumen');
        }
    }


    public function destroy($id)
    {
        $dokumen = Item::findorfail($id);
        $dokumen->delete();
        Alert::toast('Berhasil menghapus data Dokumen Sitaan.', 'success');
        return back();
    }
}
