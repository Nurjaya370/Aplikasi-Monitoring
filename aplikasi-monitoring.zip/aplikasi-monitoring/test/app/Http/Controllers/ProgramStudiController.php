<?php

namespace App\Http\Controllers;

use App\Models\ProgramStudi;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class ProgramStudiController extends Controller
{

    public function index()
    {
        $prodi = ProgramStudi::all();
        return view('prodi.data-prodi', compact('prodi'));
    }


    public function store(Request $request)
    {

        $rules = [
            'nama_prodi' => 'required || unique:program_studi',
        ];

        $text = [
            'nama_prodi.required' => 'Nama Program Studi harus diisi.',
            'nama_prodi.unique' => 'Jenis pelanggaran yang anda masukan sudah ada.',
        ];

        $request->validate($rules, $text);

        $prodi = ProgramStudi::create([
            'nama_prodi' => $request->nama_prodi,

        ]);

        if ($prodi) {
            Alert::toast('Berhasil menambah data Program Studi.', 'success');
            return redirect()->route('prodi');
        }
    }

    public function destroy($id)
    {
        $prodi = ProgramStudi::findorfail($id);
        $prodi->delete();
        Alert::toast('Berhasil menghapus data Program Studi.', 'success');
        return back();
    }
}
