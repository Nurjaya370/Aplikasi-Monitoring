<?php

namespace App\Http\Controllers;

use App\Models\Pelanggaran;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class PelanggaranController extends Controller
{

    public function index()
    {
        $pelanggaran = Pelanggaran::all();
        return view('pelanggaran.data-pelanggaran', compact('pelanggaran'));
    }


    public function store(Request $request)
    {

        $rules = [
            'nama_pelanggaran' => 'required|unique:pelanggaran',
        ];

        $text = [
            'nama_pelanggaran.required' => 'Nama Program Studi harus diisi.',
            'nama_pelanggaran.unique' => 'Jenis pelanggaran yang anda masukan sudah ada.',
        ];

        $request->validate($rules, $text);

        $pelanggaran = Pelanggaran::create([
            'nama_pelanggaran' => $request->nama_pelanggaran,

        ]);

        if ($pelanggaran) {
            Alert::toast('Berhasil menambah data Jenis Pelanggaran.', 'success');
            return redirect()->route('pelanggaran');
        }
    }


    public function destroy($id)
    {
        $pelanggaran = Pelanggaran::findorfail($id);
        $pelanggaran->delete();
        Alert::toast('Berhasil menghapus data Jenis Pelanggaran.', 'success');
        return back();
    }
}
